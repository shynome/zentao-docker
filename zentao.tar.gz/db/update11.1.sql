ALTER TABLE `zt_release` CHANGE `name` `name` varchar(255) COLLATE 'utf8_general_ci' NOT NULL DEFAULT '' AFTER `build`;
