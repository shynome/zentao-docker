ALTER TABLE  `zt_user` CHANGE  `msn`  `skype` CHAR( 90 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
